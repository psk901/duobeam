package com.shiva.duobeam

import java.util.Random
import java.util.zip.CRC32
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** LT fountain code. One packet = 12 byte header + 240 byte payload + CRC16. Same packet is used on QR and audio. */
object Fountain {
    const val BLOCK = 240
    const val HEADER = 12
    const val PKT = HEADER + BLOCK + 2
    const val MAX_FILE = 4 * 1024 * 1024
    const val MAX_CONTAINER = MAX_FILE + 300

    class Packet(val fileId: Int, val fileLen: Int, val seed: Int, val payload: ByteArray)

    fun crc16(b: ByteArray, off: Int, len: Int): Int {
        var crc = 0xFFFF
        for (i in off until off + len) {
            crc = crc xor ((b[i].toInt() and 0xFF) shl 8)
            for (j in 0 until 8) {
                crc = if ((crc and 0x8000) != 0) (crc shl 1) xor 0x1021 else (crc shl 1)
                crc = crc and 0xFFFF
            }
        }
        return crc
    }

    private fun putInt(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 24).toByte(); b[o + 1] = (v ushr 16).toByte()
        b[o + 2] = (v ushr 8).toByte(); b[o + 3] = v.toByte()
    }

    private fun getInt(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or
            ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)

    fun build(fileId: Int, fileLen: Int, seed: Int, payload: ByteArray): ByteArray {
        val out = ByteArray(PKT)
        putInt(out, 0, fileId); putInt(out, 4, fileLen); putInt(out, 8, seed)
        System.arraycopy(payload, 0, out, HEADER, BLOCK)
        val c = crc16(out, 0, PKT - 2)
        out[PKT - 2] = (c ushr 8).toByte(); out[PKT - 1] = c.toByte()
        return out
    }

    fun parse(b: ByteArray, off: Int = 0): Packet? {
        if (b.size - off < PKT) return null
        val c = crc16(b, off, PKT - 2)
        val got = ((b[off + PKT - 2].toInt() and 0xFF) shl 8) or (b[off + PKT - 1].toInt() and 0xFF)
        if (c != got) return null
        val len = getInt(b, off + 4)
        val seed = getInt(b, off + 8)
        if (len <= 0 || len > MAX_CONTAINER || seed < 0) return null
        return Packet(getInt(b, off), len, seed, b.copyOfRange(off + HEADER, off + HEADER + BLOCK))
    }

    // ---- container: [nameLen][name][data] ----
    fun pack(name: String, data: ByteArray): ByteArray {
        var nb = name.toByteArray(Charsets.UTF_8)
        if (nb.size > 255) nb = nb.copyOf(255)
        val out = ByteArray(1 + nb.size + data.size)
        out[0] = nb.size.toByte()
        System.arraycopy(nb, 0, out, 1, nb.size)
        System.arraycopy(data, 0, out, 1 + nb.size, data.size)
        return out
    }

    fun unpack(c: ByteArray): Pair<String, ByteArray>? {
        if (c.isEmpty()) return null
        val n = c[0].toInt() and 0xFF
        if (1 + n > c.size) return null
        return Pair(String(c, 1, n, Charsets.UTF_8), c.copyOfRange(1 + n, c.size))
    }

    // ---- robust soliton degree distribution ----
    private val cdfCache = HashMap<Int, DoubleArray>()

    private fun cdf(k: Int): DoubleArray = synchronized(cdfCache) { cdfCache.getOrPut(k) { buildCdf(k) } }

    private fun buildCdf(k: Int): DoubleArray {
        val c = 0.1
        val delta = 0.5
        val r = max(1.0, c * ln(k / delta) * sqrt(k.toDouble()))
        val spike = min(k, max(1, floor(k / r).toInt()))
        val mu = DoubleArray(k + 1)
        var sum = 0.0
        for (d in 1..k) {
            val rho = if (d == 1) 1.0 / k else 1.0 / (d * (d - 1.0))
            var tau = 0.0
            if (d < spike) tau = r / (d * k.toDouble())
            else if (d == spike) tau = r * ln(r / delta) / k
            mu[d] = rho + max(0.0, tau)
            sum += mu[d]
        }
        val cum = DoubleArray(k + 1)
        var acc = 0.0
        for (d in 1..k) { acc += mu[d] / sum; cum[d] = acc }
        return cum
    }

    private fun mix(x: Long): Long {
        var z = x + 0x9E3779B97F4A7C15uL.toLong()
        z = (z xor (z ushr 30)) * 0xBF58476D1CE4E5B9uL.toLong()
        z = (z xor (z ushr 27)) * 0x94D049BB133111EBuL.toLong()
        return z xor (z ushr 31)
    }

    /** Which source blocks a packet with this seed covers. Seeds < k are systematic (single block). */
    fun indices(seed: Int, k: Int): IntArray {
        if (seed < k) return intArrayOf(seed)
        val rng = Random(mix(seed.toLong()))
        val c = cdf(k)
        val u = rng.nextDouble()
        var d = 1
        while (d < k && c[d] < u) d++
        val set = LinkedHashSet<Int>()
        while (set.size < d) set.add(rng.nextInt(k))
        return set.toIntArray()
    }

    private fun xor(a: ByteArray, b: ByteArray) {
        for (i in a.indices) a[i] = (a[i].toInt() xor b[i].toInt()).toByte()
    }

    class Encoder(private val data: ByteArray) {
        val k = (data.size + BLOCK - 1) / BLOCK
        val fileId: Int = CRC32().also { it.update(data) }.value.toInt()
        private var counter = 0

        @Synchronized
        fun next(): ByteArray {
            val s = counter++
            return packet(s)
        }

        private fun packet(seed: Int): ByteArray {
            val payload = ByteArray(BLOCK)
            for (i in indices(seed, k)) {
                val off = i * BLOCK
                val n = min(BLOCK, data.size - off)
                for (j in 0 until n) payload[j] = (payload[j].toInt() xor data[off + j].toInt()).toByte()
            }
            return build(fileId, data.size, seed, payload)
        }
    }

    class Decoder(val fileId: Int, val len: Int) {
        val k = (len + BLOCK - 1) / BLOCK
        private val blocks = arrayOfNulls<ByteArray>(k)
        var solved = 0
            private set
        private val seen = HashSet<Int>()

        private class Eq(val idx: MutableSet<Int>, val data: ByteArray)

        private val adj = HashMap<Int, MutableList<Eq>>()

        fun has(seed: Int) = seen.contains(seed)

        fun add(seed: Int, payload: ByteArray): Boolean {
            if (solved == k) return true
            if (!seen.add(seed)) return false
            val data = payload.copyOf()
            val idx = HashSet<Int>()
            for (i in indices(seed, k)) {
                val b = blocks[i]
                if (b != null) xor(data, b) else idx.add(i)
            }
            if (idx.isEmpty()) return solved == k
            val queue = ArrayDeque<Pair<Int, ByteArray>>()
            if (idx.size == 1) {
                queue.add(Pair(idx.first(), data))
            } else {
                val eq = Eq(idx, data)
                for (i in idx) adj.getOrPut(i) { ArrayList() }.add(eq)
            }
            while (queue.isNotEmpty()) {
                val (i, d) = queue.removeFirst()
                if (blocks[i] != null) continue
                blocks[i] = d
                solved++
                val list = adj.remove(i) ?: continue
                for (eq in list) {
                    if (!eq.idx.remove(i)) continue
                    xor(eq.data, d)
                    if (eq.idx.size == 1) queue.add(Pair(eq.idx.first(), eq.data.copyOf()))
                }
            }
            return solved == k
        }

        /** Full container bytes if complete and checksum matches, else null. */
        fun result(): ByteArray? {
            if (solved < k) return null
            val out = ByteArray(len)
            for (i in 0 until k) {
                val off = i * BLOCK
                System.arraycopy(blocks[i]!!, 0, out, off, min(BLOCK, len - off))
            }
            val crc = CRC32().also { it.update(out) }.value.toInt()
            return if (crc == fileId) out else null
        }
    }
}
