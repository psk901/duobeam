package com.shiva.duobeam

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Point
import android.os.SystemClock
import android.util.Size
import android.view.MotionEvent
import androidx.camera.core.Camera
import androidx.camera.core.FocusMeteringAction
import java.util.concurrent.Executor
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.TimeUnit
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.max

/** Camera (QR) and microphone (ultrasound) both feed ONE fountain decoder. */
class Receiver(
    private val act: AppCompatActivity,
    private val view: PreviewView,
    private val useAudio: Boolean
) {
    @Volatile var result: ByteArray? = null
    @Volatile var error: String? = null
    @Volatile private var running = false
    @Volatile private var qrPk = 0
    @Volatile private var auPk = 0
    @Volatile private var coPk = 0
    private val busy = AtomicBoolean(false)
    private val stopped = AtomicBoolean(false)
    @Volatile private var cam: Camera? = null
    @Volatile private var auFr = 0
    private var zoom = 1f
    private var lastAdj = 0L
    private var lastSeen = 0L
    private var lastFocus = 0L
    private val frags = HashMap<Int, Array<ByteArray?>>()
    @Volatile private var solved = 0
    @Volatile private var k = 0
    @Volatile private var t0 = 0L
    @Volatile private var mic = if (useAudio) "starting" else "no permission"

    private var dec: Fountain.Decoder? = null
    private val exec = Executors.newSingleThreadExecutor()
    /** Never throws if the executor was shut down (that rejection used to crash the app after a transfer). */
    private val safe = Executor { r -> try { exec.execute(r) } catch (e: RejectedExecutionException) { } }
    private var provider: ProcessCameraProvider? = null
    private val scanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
    )

    fun start() {
        running = true
        startCamera()
        if (useAudio) startAudio()
    }

    fun stop() {
        running = false
        if (!stopped.compareAndSet(false, true)) return
        try { provider?.unbindAll() } catch (e: Exception) { }
        try { exec.execute { try { scanner.close() } catch (e: Exception) { } } } catch (e: Exception) { }
        exec.shutdown()
    }

    fun statusText(): String =
        "Blocks $solved/$k (${rate()})   QR packets $qrPk   color packets $coPk   audio packets $auPk (frames $auFr)   mic: $mic" +
            (error?.let { "\n$it" } ?: "")

    private fun rate(): String {
        if (t0 == 0L) return "0 KB/s"
        val s = (SystemClock.elapsedRealtime() - t0) / 1000.0
        return "%.1f KB/s".format(solved * Fountain.BLOCK / 1024.0 / maxOf(s, 0.5))
    }

    fun progressPermille(): Int = if (k == 0) 0 else solved * 1000 / k

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(act)
        f.addListener({
            val p = f.get()
            provider = p
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
            val selector = ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(Size(1920, 1080), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                ).build()
            val an = ImageAnalysis.Builder()
                .setResolutionSelector(selector)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            an.setAnalyzer(exec) { px ->
                val img = px.image
                if (!running || img == null || !busy.compareAndSet(false, true)) {
                    px.close()
                } else try {
                    val deg = px.imageInfo.rotationDegrees
                    scanner.process(InputImage.fromMediaImage(img, deg))
                        .addOnSuccessListener(safe) { codes -> try { onCodes(codes, px, deg) } catch (e: Exception) { } }
                        .addOnCompleteListener(safe) { px.close(); busy.set(false) }
                } catch (e: Exception) { px.close(); busy.set(false) }
            }
            p.unbindAll()
            cam = p.bindToLifecycle(act, CameraSelector.DEFAULT_BACK_CAMERA, preview, an)
            view.setOnTouchListener { v, e ->
                if (e.action == MotionEvent.ACTION_UP) { focusAt(e.x, e.y); v.performClick() }
                true
            }
        }, ContextCompat.getMainExecutor(act))
    }

    private fun onCodes(codes: List<Barcode>, px: androidx.camera.core.ImageProxy, deg: Int) {
        val bw = (if (deg % 180 == 0) px.width else px.height).toFloat()
        val bh = (if (deg % 180 == 0) px.height else px.width).toFloat()
        var bmp: Bitmap? = null
        var x0 = Float.MAX_VALUE; var y0 = Float.MAX_VALUE; var x1 = 0f; var y1 = 0f
        var color = false
        for (c in codes) {
            val raw = c.rawBytes ?: c.rawValue?.toByteArray(Charsets.ISO_8859_1) ?: continue
            onQr(raw)
            val pts = c.cornerPoints ?: continue
            for (q in pts) { x0 = minOf(x0, q.x.toFloat()); y0 = minOf(y0, q.y.toFloat()); x1 = maxOf(x1, q.x.toFloat()); y1 = maxOf(y1, q.y.toFloat()) }
            if (raw.size == Fountain.PKT + 1 && raw[Fountain.PKT] == 1.toByte()) {
                color = true
                if (bmp == null) bmp = rotated(px.toBitmap(), deg)
                try { sampleGrid(bmp, pts) } catch (e: Exception) { }
            }
        }
        autoAdjust(x1 > x0, x0 / bw, y0 / bh, x1 / bw, y1 / bh, color)
    }

    /** Auto zoom + focus: zoom in when the code block is small, out when it touches the edge, refocus on it, reset if lost. */
    private fun autoAdjust(seen: Boolean, nx0: Float, ny0: Float, nx1: Float, ny1: Float, color: Boolean) {
        val c = cam ?: return
        val now = SystemClock.elapsedRealtime()
        if (seen) lastSeen = now
        val zs = c.cameraInfo.zoomState.value ?: return
        var target = zoom
        if (seen) {
            val w = nx1 - nx0; val h = ny1 - ny0
            if (nx0 < 0.03f || ny0 < 0.03f || nx1 > 0.97f || ny1 > 0.97f) target = zoom * 0.85f
            else if (!color && w < 0.35f && h < 0.35f) target = zoom * 1.25f
        } else if (zoom > 1f && now - lastSeen > 2500) target = 1f
        target = target.coerceIn(zs.minZoomRatio, zs.maxZoomRatio)
        val changed = target != zoom
        if (changed && now - lastAdj > 900) {
            zoom = target; lastAdj = now
            try { c.cameraControl.setZoomRatio(target) } catch (e: Exception) { }
        }
        if (seen && (changed || now - lastFocus > 4000)) {
            lastFocus = now
            val fx = (nx0 + nx1) / 2; val fy = (ny0 + ny1) / 2
            act.runOnUiThread { focusAt(fx * view.width, fy * view.height) }
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val c = cam ?: return
        try {
            val pt = view.meteringPointFactory.createPoint(x, y)
            c.cameraControl.startFocusAndMetering(
                FocusMeteringAction.Builder(pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
                    .setAutoCancelDuration(3, TimeUnit.SECONDS).build()
            )
        } catch (e: Exception) { }
    }

    private fun rotated(b: Bitmap, deg: Int): Bitmap =
        if (deg == 0) b else Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg.toFloat()) }, false)

    /** Sample the colour grid using the finder QR corners as a perspective reference. */
    private fun sampleGrid(bmp: Bitmap, c: Array<Point>) {
        if (c.size < 4) return
        val dst = FloatArray(8)
        for (i in 0 until 4) { dst[2 * i] = c[i].x.toFloat(); dst[2 * i + 1] = c[i].y.toFloat() }
        val mat = Matrix()
        if (!mat.setPolyToPoly(ColorGrid.finderSrc, 0, dst, 0, 4)) return
        val n = ColorGrid.N
        val p = FloatArray(2)
        val rgb = IntArray(n * n)
        for (r in 0 until n) for (cc in 0 until n) {
            p[0] = ColorGrid.GX + (cc + 0.5f) * ColorGrid.CELL
            p[1] = ColorGrid.GY + (r + 0.5f) * ColorGrid.CELL
            mat.mapPoints(p)
            val x = p[0].toInt(); val y = p[1].toInt()
            if (x < 1 || y < 1 || x >= bmp.width - 1 || y >= bmp.height - 1) return
            var rs = 0; var gs = 0; var bs = 0
            for (dy in -1..1) for (dx in -1..1) {
                val v = bmp.getPixel(x + dx, y + dy)
                rs += (v shr 16) and 255; gs += (v shr 8) and 255; bs += v and 255
            }
            rgb[r * n + cc] = ((rs / 9) shl 16) or ((gs / 9) shl 8) or (bs / 9)
        }
        val sum = Array(8) { IntArray(4) }
        for (cc in 0 until n) {
            val v = rgb[cc]; val s = sum[cc and 7]
            s[0] += (v shr 16) and 255; s[1] += (v shr 8) and 255; s[2] += v and 255; s[3]++
        }
        val ref = Array(8) { i -> IntArray(3) { j -> sum[i][j] / sum[i][3] } }
        val idx = IntArray(n * (n - 1))
        for (i in idx.indices) {
            val v = rgb[n + i]
            val r = (v shr 16) and 255; val g = (v shr 8) and 255; val b = v and 255
            var best = 0; var bd = Int.MAX_VALUE
            for (k2 in 0 until 8) {
                val dr = r - ref[k2][0]; val dg = g - ref[k2][1]; val db = b - ref[k2][2]
                val d = dr * dr + dg * dg + db * db
                if (d < bd) { bd = d; best = k2 }
            }
            idx[i] = best
        }
        val bytes = ColorGrid.fromCells(idx)
        for (i in 0 until ColorGrid.PKTS) Fountain.parse(bytes, i * Fountain.PKT)?.let { add(it, 2) }
    }

    private fun onQr(raw: ByteArray) {
        var o = 0
        while (o + Fountain.PKT <= raw.size) {
            Fountain.parse(raw, o)?.let { add(it, 0) }
            o += Fountain.PKT
        }
    }

    private fun onAudioFrame(f: ByteArray) {
        val pid = f[0].toInt() and 255
        val idx = f[1].toInt() and 255
        if (idx >= Modem.FRAGS) return
        auFr++
        if (frags.size > 4) frags.clear()
        val arr = frags.getOrPut(pid) { arrayOfNulls(Modem.FRAGS) }
        if (arr[idx] == null) arr[idx] = f.copyOfRange(2, 2 + Modem.FRAG)
        if (arr.all { it != null }) {
            frags.remove(pid)
            val b = ByteArray(Modem.FRAGS * Modem.FRAG)
            for (i in 0 until Modem.FRAGS) arr[i]!!.copyInto(b, i * Modem.FRAG)
            Fountain.parse(b.copyOf(Fountain.PKT))?.let { add(it, 1) }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startAudio() {
        thread(name = "mic-rx") {
            val min = AudioRecord.getMinBufferSize(Modem.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            var r: AudioRecord? = null
            for (src in intArrayOf(MediaRecorder.AudioSource.UNPROCESSED, MediaRecorder.AudioSource.MIC)) {
                try {
                    val c = AudioRecord(src, Modem.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, Modem.SR))
                    if (c.state == AudioRecord.STATE_INITIALIZED) { r = c; break } else c.release()
                } catch (e: Exception) { }
            }
            if (r == null) { mic = "unavailable"; return@thread }
            r.startRecording()
            mic = "listening"
            val demods = listOf(Modem.Demod(Modem.ULTRA) { onAudioFrame(it) }, Modem.Demod(Modem.AUDIBLE) { onAudioFrame(it) })
            val buf = ShortArray(2048)
            while (running) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) { for (d in demods) d.feed(buf, n) } else if (n < 0) break
            }
            try { r.stop() } catch (e: Exception) { }
            r.release()
        }
    }

    @Synchronized
    private fun add(p: Fountain.Packet, src: Int) {
        if (result != null) return
        if (t0 == 0L) t0 = SystemClock.elapsedRealtime()
        var d = dec
        if (d == null) {
            d = Fountain.Decoder(p.fileId, p.fileLen)
            dec = d
            k = d.k
        }
        if (p.fileId != d.fileId || p.fileLen != d.len) return
        if (!d.has(p.seed)) { when (src) { 0 -> qrPk++; 1 -> auPk++; else -> coPk++ } }
        val done = d.add(p.seed, p.payload)
        solved = d.solved
        if (done) {
            val c = d.result()
            if (c != null) result = c
            else { error = "Checksum mismatch - restarting"; dec = null; solved = 0; k = 0 }
        }
    }
}
