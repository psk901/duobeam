package com.shiva.duobeam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private var sender: Sender? = null
    private var receiver: Receiver? = null
    private var tickFn: (() -> Unit)? = null
    private val ticker = object : Runnable {
        override fun run() { tickFn?.invoke(); ui.postDelayed(this, 100) }
    }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) startSend(uri)
    }
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (has(Manifest.permission.CAMERA)) startReceive(has(Manifest.permission.RECORD_AUDIO))
        else toast("Camera permission is required to scan the QR code")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        setContentView(root)
        showMenu()
        ui.post(ticker)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (sender != null || receiver != null) showMenu() else finish()
            }
        })
    }

    override fun onDestroy() {
        ui.removeCallbacks(ticker)
        stopAll()
        super.onDestroy()
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun has(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun label(t: String, size: Float = 16f) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE)
    }
    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; setOnClickListener { onClick() }
    }
    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(Color.parseColor("#101418"))
    }
    private fun setScreen(v: LinearLayout) { root.removeAllViews(); root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH)) }

    private fun stopAll() {
        sender?.stop(); sender = null
        receiver?.stop(); receiver = null
        tickFn = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---------- menu ----------
    private fun showMenu() {
        stopAll()
        val col = column()
        col.gravity = Gravity.CENTER
        col.addView(label("DuoBeam", 32f))
        col.addView(label("Offline file transfer: QR fountain codes + ultrasound/sound at the same time. No WiFi, internet or Bluetooth.", 14f).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(32))
        })
        col.addView(btn("SEND FILE") { pick.launch(arrayOf("*/*")) }, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(btn("RECEIVE FILE") {
            val need = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO).filter { !has(it) }
            if (need.isEmpty()) startReceive(true) else perms.launch(need.toTypedArray())
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(label("Max file size 4 MB. Keep phones 10-30 cm apart, screen facing the camera, volume up.", 12f).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(24), 0, 0)
        })
        setScreen(col)
    }

    // ---------- send ----------
    private fun startSend(uri: Uri) {
        Thread {
            try {
                var name = "file"
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
                }
                val data = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                if (data.isEmpty() || data.size > Fountain.MAX_FILE) {
                    runOnUiThread { toast("File must be between 1 byte and 4 MB") }
                    return@Thread
                }
                val container = Fountain.pack(name, data)
                runOnUiThread { showSender(name, container) }
            } catch (e: Exception) {
                runOnUiThread { toast("Cannot read file: ${e.message}") }
            }
        }.start()
    }

    private fun showSender(name: String, container: ByteArray) {
        stopAll()
        val s = Sender(container)
        sender = s
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.also { it.screenBrightness = 1f }
        (getSystemService(AUDIO_SERVICE) as AudioManager).let {
            it.setStreamVolume(AudioManager.STREAM_MUSIC, it.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0)
        }
        val col = column()
        val img = ImageView(this).apply {
            setBackgroundColor(Color.WHITE); scaleType = ImageView.ScaleType.FIT_CENTER
        }
        col.addView(img, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val status = label("", 13f)
        col.addView(status)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(CheckBox(this).apply {
            text = "QR"; isChecked = true; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, c -> s.qrOn = c }
        })
        row.addView(CheckBox(this).apply {
            text = "Ultrasound"; isChecked = true; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, c -> s.audioOn = c }
        })
        col.addView(row)
        row.addView(CheckBox(this).apply {
            text = "Audible band"; setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, c -> s.audible = c }
        })
        val tb = Button(this)
        val label = { t: Int -> "Optical mode: " + (if (t == 0) "COLOR grid (experimental)" else "QR x$t") + " (tap to change)" }
        tb.text = label(s.tiles)
        tb.setOnClickListener {
            s.tiles = when (s.tiles) { 4 -> 2; 2 -> 1; 1 -> 0; else -> 4 }
            tb.text = label(s.tiles)
        }
        col.addView(tb)
        val fpsLabel = label("QR speed: 12 frames/s", 13f)
        col.addView(fpsLabel)
        col.addView(SeekBar(this).apply {
            max = 18; progress = 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    s.fps = p + 2; fpsLabel.text = "QR speed: ${p + 2} frames/s (lower if receiver misses frames)"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })
        col.addView(btn("STOP") { showMenu() })
        setScreen(col)
        s.start()
        var last: Bitmap? = null
        tickFn = {
            val b = s.bitmap
            if (b != null && b !== last) { img.setImageBitmap(b); last = b }
            status.text = "$name - ${s.blocks} blocks | QR frames ${s.qrFrames} | audio frames ${s.audioFrames}\nKeep this open until the receiver says done."
        }
    }

    // ---------- receive ----------
    private fun startReceive(audioOk: Boolean) {
        stopAll()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val col = column()
        val pv = PreviewView(this)
        col.addView(pv, LinearLayout.LayoutParams(MATCH, 0, 1f))
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        col.addView(bar)
        val status = label("Point the camera at the sender's QR code.", 13f)
        col.addView(status)
        col.addView(btn("STOP") { showMenu() })
        setScreen(col)
        val r = Receiver(this, pv, audioOk)
        receiver = r
        r.start()
        var handled = false
        tickFn = {
            status.text = r.statusText()
            bar.progress = r.progressPermille()
            val res = r.result
            if (res != null && !handled) { handled = true; onReceived(res) }
        }
    }

    private fun onReceived(container: ByteArray) {
        receiver?.stop()
        val up = try { Fountain.unpack(container) } catch (e: Exception) { null }
        if (up == null) { toast("Corrupt container"); showMenu(); return }
        val safe = up.first.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "received.bin" }
        val msg = try {
            saveToDownloads(safe, up.second)
            "Saved to Downloads/$safe (${up.second.size} bytes)"
        } catch (e: Exception) { "Could not save: ${e.message}" }
        AlertDialog.Builder(this).setTitle("Transfer complete").setMessage(msg)
            .setPositiveButton("OK") { _, _ -> showMenu() }.setCancelable(false).show()
    }

    private fun saveToDownloads(name: String, data: ByteArray) {
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
        contentResolver.openOutputStream(uri)!!.use { it.write(data) }
        v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
        contentResolver.update(uri, v, null, null)
    }
}
