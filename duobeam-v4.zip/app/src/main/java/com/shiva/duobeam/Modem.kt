package com.shiva.duobeam

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * 16-FSK modem, 20 ms symbols (4 bits each), two bands: ULTRA 17-20 kHz and AUDIBLE 2.4-5.4 kHz.
 * Sends SHORT frames (28 bytes, CRC16) so one bad symbol only costs 1.2 s; packets are split into fragments.
 * Frame = 4 preamble symbols (16.4k/16.8k alternating) + 156 data symbols + 2 symbols of silence.
 */
object Modem {
    const val SR = 44100
    const val SYM = 880
    const val HOP = 220
    const val PRE = 4
    const val GAP = 2
    const val FRAG = 24
    const val FRAME = FRAG + 4           // pid, idx, 24 data bytes, crc16
    const val NSYM = FRAME * 2
    val FRAGS = (Fountain.PKT + FRAG - 1) / FRAG
    private const val AMP = 0.85
    private const val RAMP = 40
    private const val MIN_ENERGY = 2e-6f
    private const val RATIO = 6f

    class Band(base: Double, p0: Double, p1: Double) {
        val freq = DoubleArray(18) { when { it < 16 -> base + 200.0 * it; it == 16 -> p0; else -> p1 } }
    }
    val ULTRA = Band(17000.0, 16400.0, 16800.0)
    val AUDIBLE = Band(2400.0, 1600.0, 2000.0)

    fun crc16(b: ByteArray, len: Int): Int {
        val c = java.util.zip.CRC32(); c.update(b, 0, len); return (c.value and 0xFFFF).toInt()
    }

    fun modulate(pkt: ByteArray, band: Band): ShortArray {
        val syms = IntArray(PRE + NSYM)
        for (j in 0 until PRE) syms[j] = 16 + (j and 1)
        for (i in 0 until FRAME) {
            val b = pkt[i].toInt() and 0xFF
            syms[PRE + 2 * i] = b ushr 4
            syms[PRE + 2 * i + 1] = b and 0x0F
        }
        val out = ShortArray((PRE + NSYM + GAP) * SYM)
        for (s in syms.indices) {
            val w = 2.0 * PI * band.freq[syms[s]] / SR
            for (n in 0 until SYM) {
                val env = when {
                    n < RAMP -> n / RAMP.toDouble()
                    n >= SYM - RAMP -> (SYM - 1 - n) / RAMP.toDouble()
                    else -> 1.0
                }
                out[s * SYM + n] = (sin(w * n) * AMP * env * 32767.0).toInt().toShort()
            }
        }
        return out
    }

    class Demod(private val band: Band, private val onFrame: (ByteArray) -> Unit) {
        private var buf = FloatArray(SR * 3)
        private var bufLen = 0
        private var bufBase = 0L
        private var prev = 0f
        private val energies = ArrayList<FloatArray>()
        private var eBase = 0
        private var nextHop = 0
        private var scan = 0
        private var dataStart = -1
        private val coeff = DoubleArray(18) { 2.0 * cos(2.0 * PI * band.freq[it] / SR) }

        fun feed(s: ShortArray, n: Int) {
            if (bufLen + n > buf.size) buf = buf.copyOf(max(buf.size * 2, bufLen + n))
            for (i in 0 until n) {
                val cur = s[i] / 32768f
                buf[bufLen + i] = (cur - prev) * 0.5f // pre-emphasis: suppress speech / low rumble
                prev = cur
            }
            bufLen += n
            computeEnergies()
            process()
            trim()
        }

        private fun computeEnergies() {
            while (true) {
                val start = nextHop.toLong() * HOP - bufBase
                if (start + SYM > bufLen) break
                energies.add(window(start.toInt()))
                nextHop++
            }
        }

        private fun window(off: Int): FloatArray {
            val e = FloatArray(18)
            for (t in 0 until 18) {
                val c = coeff[t]
                var s1 = 0.0
                var s2 = 0.0
                for (i in off until off + SYM) {
                    val s0 = buf[i] + c * s1 - s2
                    s2 = s1
                    s1 = s0
                }
                e[t] = ((s1 * s1 + s2 * s2 - c * s1 * s2) / (SYM.toDouble() * SYM)).toFloat()
            }
            return e
        }

        private fun en(h: Int): FloatArray = energies[h - eBase]

        private fun matchPre(n: Int): Boolean {
            for (j in 0 until PRE) {
                val e = en(n + 4 * j)
                val x = 16 + (j and 1)
                val v = e[x]
                if (v < MIN_ENERGY) return false
                for (t in 0 until 18) if (t != x && e[t] * RATIO > v) return false
            }
            return true
        }

        private fun score(n: Int): Float {
            var sc = 0f
            for (j in 0 until PRE) {
                val e = en(n + 4 * j)
                var tot = 1e-12f
                for (t in 0 until 18) tot += e[t]
                sc += e[16 + (j and 1)] / tot
            }
            return sc
        }

        private fun argmax16(e: FloatArray): Int {
            var b = 0
            for (t in 1 until 16) if (e[t] > e[b]) b = t
            return b
        }

        private fun process() {
            while (true) {
                if (dataStart < 0) {
                    if (scan < eBase) scan = eBase
                    if (scan + 14 >= nextHop) break
                    if (matchPre(scan)) {
                        var best = scan
                        var bs = score(scan)
                        for (d in 1..2) {
                            val sc = score(scan + d)
                            if (sc > bs) { bs = sc; best = scan + d }
                        }
                        dataStart = best + 4 * PRE
                    } else {
                        scan++
                    }
                } else {
                    val last = dataStart + 4 * (NSYM - 1)
                    if (last >= nextHop) break
                    val bytes = ByteArray(FRAME)
                    for (i in 0 until FRAME) {
                        val hi = argmax16(en(dataStart + 4 * (2 * i)))
                        val lo = argmax16(en(dataStart + 4 * (2 * i + 1)))
                        bytes[i] = ((hi shl 4) or lo).toByte()
                    }
                    val crc = ((bytes[FRAME - 2].toInt() and 0xFF) shl 8) or (bytes[FRAME - 1].toInt() and 0xFF)
                    if (crc == crc16(bytes, FRAME - 2)) onFrame(bytes)
                    scan = dataStart + 4 * NSYM
                    dataStart = -1
                }
            }
        }

        private fun trim() {
            val keepFrom = if (dataStart >= 0) dataStart else scan
            val drop = keepFrom - eBase
            if (drop > 2000) {
                energies.subList(0, drop).clear()
                eBase += drop
            }
            val keepSamples = nextHop.toLong() * HOP - bufBase
            if (keepSamples > SR) {
                val k = keepSamples.toInt()
                System.arraycopy(buf, k, buf, 0, bufLen - k)
                bufLen -= k
                bufBase += k
            }
        }
    }
}
