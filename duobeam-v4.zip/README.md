# DuoBeam
Offline phone-to-phone file transfer. One LT fountain-code stream is sent over three channels at once: an 8-colour grid (with a finder QR), raw-binary QR, and ultrasound. The receiver merges all of them into one decoder. No WiFi/internet/Bluetooth.
Build: push to GitHub -> Actions builds DuoBeam.apk -> Releases > latest.
